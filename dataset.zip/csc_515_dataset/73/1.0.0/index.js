#!/usr/bin/env node
const yargs = require("yargs");
const axios = require("axios");
// const util = require('util');
// const exec = util.promisify(require('child_process').exec);
const {scan} = require("./scanner.js");

yargs.command({
    command: 'scan',
    describe: 'Run scan base on what is added in to the customized dev ops',
    builder: (yargs) => {
      yargs.options({
        apikey: {
            describe: 'ArmourZero Domain API Key is needed',
            demandOption: true, // Makes the 'apikey' parameter required
            type: 'string',     // Specifies the data type
        },
        pipekey: {
          describe: 'ArmourZero Pipeline Key is needed',
          demandOption: true, // Makes the 'pipekey' parameter required
          type: 'string',     // Specifies the data type
        },
      });
    },
    handler: async (argv) => {
      // Implement the 'testing' command logic here
      //HALLO
      const apiKey = argv.apikey;
      const pipeKey = argv.pipekey;
      console.log('Running tests on PipeKey:', pipeKey);
  
      try {
          const postData = {
            apikey : apiKey,
            pipekey: pipeKey
          }
        //   const response = await axios.post('http://localhost/api/scan/pipeline');
          let command = "bearer scan -f html . > result.html"
          scan(command, pipeKey)
          // Handle the response here
          
          const { stdout, stderr } = await exec('stripe -v');
          console.log('Command output:', stdout);
      } catch (error) {
          // Handle any errors here
          console.error('Error:', error);
      }
    }
});

yargs.argv;