const { exec, spawn } = require('child_process');
const fs = require('fs');
const axios = require('axios')

const scan = (command, pipekey) => {
    let args = [];
    const timeout = 3000; // 3 seconds in milliseconds
    let isResponseSent = false;    
    // Create a write stream to the output file
    const outputFile = fs.createWriteStream('scan_output.log');
    // Spawn the child process
    const childProcess = spawn(command,[]);
    // Pipe the output to the file
    childProcess.stdout.pipe(outputFile);

    childProcess.on('exit', (code, signal) => {
        console.log(`Child process exited with code ${code} and signal ${signal}`);
        if(code === 2){
            // Process the report
            handleProcessExit(pipekey)
        } else {
            discordhook(`${pipekey} - :warning: Child process exited with code ${code}`);
        }
    });
    
    // Event handlers for capturing the output and errors
    childProcess.stdout.on('data', (data) => {
        console.log(`Command output: ${data}`);
    });

    childProcess.stderr.on('data', (data) => {
        console.error(`Zap Error: ${data}`);
        if (!isResponseSent) {
            isResponseSent = true;
            return false;
            // return res.status(500).json({ error: 'Internal Server Error' });
        }
    });

    const timer = setTimeout(() => {
        // If this callback is reached, it means no error event was triggered within 4 seconds
        if (!isResponseSent) {
          isResponseSent = true;
          return true;
        //   return res.sendApiResponse({ process: 1 , results:`${pipekey}Running` });
        }
      }, timeout);
};

const handleProcessExit = async (pipeKey) => {
    try {
        discordhook(`:white_check_mark: PipeKey Scan : ${pipeKey} Done`);
        // resultHook();
      } catch (error) {
        console.error(error);
      }
}

function discordhook(msg) {
    try {
        const webhookUrl = "https://discord.com/api/webhooks/1136149056083722290/J4llAw5ODOBCEw-7AIqtdVAk3viC2j7toYciqv0VWO7Fjwfhfsi2YTOrvFk9xBCX0f3z";
            
        // Example payload for sending a message
        const payload = {
          content: msg,
        };

        // Make a POST request to the Discord webhook URL
        axios.post(webhookUrl, payload);
      } catch (error) {
        console.error('Error sending webhook:', error.message);
      }
}

module.exports = {
    scan
};