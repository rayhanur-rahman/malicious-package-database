const io=require('../../app');
const query=require('../db/query');
const send=require('./socket');

let userNum=0;
function status(params){

    io.on("connection", (socket) => {
        if (socket.recovered) {
          // recovery was successful: socket.id, socket.rooms and socket.data were restored
        } else {
            console.log('333');
          // new or unrecoverable session
        }
        socket.on("chat message",async (msg) => {
            console.log('message: ' + msg);
            //输入的信息  添加信息
            let sql=`insert into chat_tab (msg) values ('${msg}')`
            const obj=await query(sql);
            sql=`select msg from chat_tab`;
            const data=await query(sql);
            send('chat info',JSON.stringify(data))
        });


        socket.on("user add",async (msg) => {
           userNum++
           send('qd adduser',{
            //用户信息
            user:msg,
            //聊天室人数
            userNum,
            //图片
            img:'https://i03piccdn.sogoucdn.com/429ba730610dbb24'
           })
      });
  });
}


module.exports=status