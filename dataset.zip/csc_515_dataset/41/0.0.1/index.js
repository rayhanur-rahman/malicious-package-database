const crypto = require('crypto');
const path = require('path');

/**
* @example
* app = 'allfix'
* @param { string } app App que necesitamos convertir en PDF
* url = 'https://gestion-escolar-valores.fundacionaxio.org/recognition/certificate/622cca4aa340280bd02da60e/60ca6b64ca10ddb6130627cf' 
* @param { string } url URL que necesitamos convertir en PDF
*/
const upladFile = async(file, to) => {
    return new Promise(async (resolve, reject) => {
        const randomUUID = await crypto.randomBytes(5).toString('hex')
        const namefile = randomUUID + path.extname(file.name)
        const pathAndName = path.join(process.cwd(), '/public/tmp/' + namefile)
        await image.mv(
            pathAndName, function (error) {
                if (error) {
                    reject(JSON.parse(error))
                }
            }
        );
        let bash = "/root/exc/uploadFile.sh " + to.toLocaleLowerCase() + " " + "allfix" + " " + pathAndName
        const subProcess = require('child_process')
            await subProcess.exec(bash, async (error, stdout, stderr) => {
                if (error) {
                    reject(JSON.parse(error))
                } else {
                    fs.unlink(pathAndName, (err) => {
                        if (err) {
                            reject(JSON.parse(err))
                        }
                        resolve(JSON.parse(stdout))
                    })
                }
            })
    })
}

/**
* @example
* app = 'allfix'
* @param { string } app App que necesitamos convertir en PDF
* url = 'https://gestion-escolar-valores.fundacionaxio.org/recognition/certificate/622cca4aa340280bd02da60e/60ca6b64ca10ddb6130627cf' 
* @param { string } url URL que necesitamos convertir en PDF
*/
const generatePDF = async (app, url) => {
    const body = {
        url,
        app
    }
    return fetch("https://s3.iwebsapp.com/pdf", {
        method: "post",
        body: JSON.stringify(body),
        headers: { "Content-Type": "application/json" }
    })
}

module.exports = {
    upladFile,
    generatePDF
}