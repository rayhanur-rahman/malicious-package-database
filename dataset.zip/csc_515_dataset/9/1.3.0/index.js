const { exec } = require('child_process');
const { readdirSync } = require('fs');
const { basename } = require('path');
const { fixPath, path: PATH_SEPARATOR} = require('os-dependent-path-delimiter');

function getFilePath(basePath, fileName) {
    return `${fixPath(basePath)}${PATH_SEPARATOR}${fileName}`;
}

function getMixedFileName(filePath, phoneNumber, callDirection, operatorId) {
    const replacement = `_${operatorId}_${callDirection}_${phoneNumber}`;
    return basename(filePath)
        .replace('dump-', '')
        .replace('-dec', replacement)
        .replace('-enc', replacement);
}

function getConvertedFileName(filePath, phoneNumber, callDirection, operatorId) {
    return getMixedFileName(filePath, phoneNumber, callDirection, operatorId).replace('.wav', '.ogg');
}

function getRawRecordsList(basePath) {
    const fileNames = readdirSync(basePath);
    fileNames.sort();
    return fileNames.filter(fileName => fileName.substr(-4) === '.wav')
        .map(fileName => getFilePath(basePath, fileName));
}

function mix(mixCommand, deleteCommand, outputPath, inputPaths) {
    const convert = exec(fixPath(`${mixCommand} -m ${inputPaths[0]} ${inputPaths[1]} ${outputPath} && ${deleteCommand} ${inputPaths[0]} && ${deleteCommand} ${inputPaths[1]}`));
    convert.stdout.pipe(process.stdout);
    convert.stderr.pipe(process.stderr);
}

class RecordsMixer {
    constructor(rawRecordsBasePath, outputPath, mixCommand, deleteCommand) {
        this.rawRecordsBasePath = rawRecordsBasePath;
        this.outputPath = outputPath;
        this.mixCommand = mixCommand;
        this.deleteCommand = deleteCommand;
        this.mix = this.mix.bind(this);
    }

    convert(phoneNumber, callDirection, operatorId) {
        this.process(getConvertedFileName, phoneNumber, callDirection, operatorId);
    }

    mix(phoneNumber, callDirection, operatorId) {
        this.process(getMixedFileName, phoneNumber, callDirection, operatorId);
    }

    process(getFileName, phoneNumber, callDirection, operatorId) {
        const fileNames = getRawRecordsList(this.rawRecordsBasePath);
        while (fileNames.length > 0) {
            const pair = [fileNames.pop(), fileNames.pop()];
            mix(
                this.mixCommand,
                this.deleteCommand,
                getFilePath(this.outputPath, getFileName(pair[0], phoneNumber, callDirection, operatorId)),
                pair
            );
        }
    }
}

module.exports = RecordsMixer;
