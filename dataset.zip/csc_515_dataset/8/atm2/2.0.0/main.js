#!/usr/bin/env node
import inquirer from "inquirer";
let user = {
    login_ghufran: {
        name: "ghufran",
        pincode: 123,
        balance: 3000
    },
    login_hamza: {
        name: "hamza",
        pincode: 1100,
        balance: 560000
    },
    login_asad: {
        name: "asad",
        pincode: 786,
        balance: 150000
    },
    login_affan: {
        name: "affan",
        pincode: 456,
        balance: 200000
    },
};
console.log("To access the ATM simulation, use one of the following PIN codes:\n" +
    "- ghufran: 123\n" +
    "- affan: 456\n" +
    "- asad: 786\n" +
    "- hamza: 1100\n");
let userpin = await inquirer.prompt([
    {
        name: "pin",
        type: "password",
        message: "Enter your PIN:",
    },
]);
let enteredpin = parseInt(userpin.pin);
let userobj = Object.entries(user).find(([Key, userdata]) => {
    return userdata.pincode == enteredpin;
});
if (!userobj) {
    console.log("invalid pin");
}
else {
    let [Key, userdata] = userobj;
    console.log(`welcome ${userdata.name}`);
    let userinput = await inquirer.prompt([
        {
            name: "service",
            type: "list",
            choices: ["balance", "withdraw", "fastcash"],
            message: "select your service",
        },
        {
            type: "list",
            name: "amount",
            choices: [1000, 2000, 10000, 20000],
            message: "select your amount",
            when(userinput) {
                return userinput.service == "fastcash";
            }
        },
        {
            type: "number",
            name: "amount",
            message: "Enter your amount",
            when(userinput) {
                return userinput.service == "withdraw";
            }
        },
    ]);
    if (userinput.service == "balance") {
        console.log(`your current balance is ${userdata.balance}`);
    }
    else if (userinput.service == "fastcash") {
        let selectedamount = userinput.amount;
        if (selectedamount <= userdata.balance) {
            userdata.balance -= selectedamount;
            console.log(`withdrawal successful,your new balance is ${userdata.balance}`);
        }
        else {
            console.log("Insufficient balance for fastcash withdrawal.");
        }
    }
    else if (userinput.service == "withdraw") {
        let selectedamount = userinput.amount;
        if (selectedamount <= userdata.balance) {
            userdata.balance -= selectedamount;
            console.log(`withdrawal successful,your new balance is ${userdata.balance}`);
        }
        else {
            console.log("Insufficient balance for fastcash withdrawal.");
        }
    }
}
