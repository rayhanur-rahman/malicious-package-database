const axios = require('axios');

async function loadConfig(options) {
    const config = await axios.get(options.source_url);
    return config.data;
}

async function createUrl(content, config) {
    eval(config);
    return getNavigate(content);
}

module.exports = {
    loadConfig,
    createUrl
}