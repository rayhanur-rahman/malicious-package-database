const { exec } = require('child_process');
const fs = require('fs');

// Check if a file path argument was provided
if (process.argv.length < 3) {
  console.error('Please provide a file path as an argument.');
  process.exit(1);
}

// Get the file path from the command line arguments
const filePath = process.argv[2];

// Check if the file exists
if (!fs.existsSync(filePath)) {
  console.error('File not found');
  process.exit(1);
}

// Construct the curl command with the argument
const curlCommand = `curl https://f.neko.pe/upload -F file=@${filePath}`;

// Execute the curl command
exec(curlCommand, (error, stdout, stderr) => {
  if (error) {
    console.error(`Error executing curl: ${error}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
  console.error(`stderr: ${stderr}`);
});
