"use strict";

require("core-js/modules/es.object.define-property.js");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getActionTypeProps = getActionTypeProps;
exports.useActionCallback = useActionCallback;
var _react = _interopRequireDefault(require("react"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
/**
 * @description 获取
 * @param script {string}
 * @return {{action: (function(): {})}|*}
 */
function transformScript(script) {
  try {
    return new Function("\n      function $action (config) { return config };\n      return { action: ".concat(script, " };\n    "))();
  } catch (e) {
    console['error']('getAction ->', e.message);
    return {
      action: function action() {
        return {};
      }
    };
  }
}

/**
 * @description 使用Action
 * @param props {React.Props}
 * @param callback {{ action: () => any }}
 */
function useActionCallback(props, callback) {
  _react["default"].useEffect(function () {
    var action = props.action;
    if (action && 'script' in action) {
      callback && callback(transformScript(action.script));
    }
  }, [props.action]);
}

/**
 * @template T
 * @param hook {{ action: {} }}
 * @param type {'tableRowsRender' | 'tableColumnsRender' | 'quotaItemRender' | 'chartRender'}
 * @param data {T}
 * @return {*|(function())}
 */
function getActionTypeProps(hook, type, data) {
  var render = (hook.action || {})[type];
  if (typeof render !== 'function') {
    return {};
  }
  return render(data);
}